<?php
$_['entry_sensebank_text_title'] = 'Credit Card / Debit Card [Sensebank]';
$_['button_confirm'] = 'Confirm Order';
$_['error_title'] = 'Error';
$_['error_continue'] = 'Back to shopping cart';