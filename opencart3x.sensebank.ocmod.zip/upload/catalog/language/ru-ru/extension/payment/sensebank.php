<?php
$_['entry_sensebank_text_title'] = 'Оплата банковской картой [Sensebank]';
$_['button_confirm'] = 'Перейти к оплате';
$_['error_title'] = 'Ошибка';
$_['error_continue'] = 'Вернуться в корзину';